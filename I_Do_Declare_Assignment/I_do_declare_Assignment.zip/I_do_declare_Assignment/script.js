var numNeg = -100;
console.log(numNeg);

var numPos = 22;
console.log(numPos);

var numLucky = 16;
console.log(numLucky);

var numSpecial = 5;
console.log(numSpecial);

var string1 = 'Coding Dojo!';
console.log("This is for ",string1);

var neighborhood = "West Town"
console.log("I live in ",neighborhood);

var city = 'Chicago';
console.log("I'm new to ", city);

var iMissMyDog = true;
console.log(iMissMyDog);

var chicagoIsWarm = false;
console.log(chicagoIsWarm);

var arr = [];
console.log(arr);