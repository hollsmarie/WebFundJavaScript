var HOUR = 8;
var MINUTE = 50;
var PERIOD = "AM";

if( MINUTE >= 45)
{
    if(PERIOD == "AM")
    {
        console.log("It's almost 9 in the morning!");
    }
    else 
    {
        console.log("It's " + HOUR + ":" + MINUTE + PERIOD)
    }
}



var HOUR1 = 6;
var MINUTE1 = 03;
var PERIOD1 = "PM";

if( MINUTE1 <= 30)
{
    if(PERIOD1 == "PM")
    {
        console.log("It's just after 6 in the evening!");
    }
    else
    {
    console.log("It's " + HOUR1 + ":" + MINUTE1 + PERIOD1)
    }
}


var HOUR2 = 6;
var MINUTE2 = 10;
var PERIOD2 = "AM";

if( MINUTE2 <= 15)
{
    if(PERIOD2 == "PM")
    {
        console.log("It's just after 6 in the evening!");
    }
    else
    {
    console.log("It's " + HOUR2 + ":" + MINUTE2 + " " + PERIOD2)
    }
}


var HOUR2 = 6;
var MINUTE2 = 10;
var PERIOD2 = "AM";

if( MINUTE2 <= 15)
{
    if(PERIOD2 == "PM")
    {
        console.log("It's just after 6 in the evening!");
    }
    else
    {
    console.log("It's " + HOUR2 + ":" + MINUTE2 + " " + PERIOD2)
    }
}
